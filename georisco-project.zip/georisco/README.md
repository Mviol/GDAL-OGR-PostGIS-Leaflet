# GeoRisco 🌊🗺️

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![PostGIS](https://img.shields.io/badge/PostGIS-3.4-blue.svg)](https://postgis.net)
[![Leaflet](https://img.shields.io/badge/Leaflet-1.9-green.svg)](https://leafletjs.com)

**Sistema de Informação Geográfica (SIG) web completo** focado em **análise de risco de enchentes urbanas**.

Integra de forma didática e funcional:

- **GDAL/OGR** → ingestão, conversão e processamento de dados geoespaciais  
- **TerraLib** → módulo didático de análise espacial avançada  
- **Leaflet** → visualização interativa no navegador  
- **PostGIS** → banco de dados espacial de produção  

---

## Demonstração rápida

```bash
git clone https://github.com/seu-usuario/georisco.git
cd georisco
cp .env.example .env
docker compose up --build
```

- Mapa: http://localhost:8080  
- API + Swagger: http://localhost:8000/docs  

O mapa já funciona com dados de demonstração mesmo sem carregar arquivos externos.

---

## Funcionalidades

- Pipeline de dados com GDAL/OGR (Shapefile → GeoJSON → PostGIS)
- API REST (FastAPI) que devolve GeoJSON
- Mapa Leaflet com:
  - Camadas alternáveis
  - Filtro por nível de risco
  - Popups informativos
  - Legenda
  - Estatísticas em tempo real
- Análises espaciais: buffer, interseção, área, proximidade
- Docker Compose completo (banco + API + frontend)

---

## Estrutura do repositório

```text
georisco/
├── docker-compose.yml
├── src/
│   ├── pipeline/          # GDAL/OGR scripts
│   ├── backend/           # FastAPI
│   └── frontend/          # Leaflet
├── data/
├── docs/
├── scripts/
└── notebooks/
```

---

## Níveis de uso

| Nível        | O que fazer                                      |
|--------------|--------------------------------------------------|
| Iniciante    | `docker compose up` e explorar o mapa            |
| Intermediário| Adicionar Shapefiles e rodar o pipeline          |
| Avançado     | Estender análises ou integrar TerraLib nativo    |

---

## Documentação

- [Arquitetura](docs/arquitetura.md)
- [Pipeline de dados](docs/pipeline-dados.md)
- [Integração TerraLib](docs/terra-lib-integracao.md)

---

## Licença

MIT © 2026 GeoRisco Contributors
