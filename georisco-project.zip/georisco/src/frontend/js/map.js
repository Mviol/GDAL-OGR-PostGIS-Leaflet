/**
 * GeoRisco – Leaflet map logic
 */

const API_BASE = "http://localhost:8000";

// Color scale by risk level
const RISK_COLORS = {
  muito_alto: "#d32f2f",
  alto: "#f57c00",
  medio: "#fbc02d",
  baixo: "#388e3c",
};

const map = L.map("map", {
  center: [-19.92, -43.94], // example center (Belo Horizonte region)
  zoom: 12,
  zoomControl: true,
});

// Base layers
const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: "© OpenStreetMap",
}).addTo(map);

const cartoDark = L.tileLayer(
  "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
  {
    maxZoom: 19,
    attribution: "© CARTO",
  }
);

L.control.layers(
  { "OpenStreetMap": osm, "Carto Dark": cartoDark },
  null,
  { position: "topright" }
).addTo(map);

// Layer groups
let riskLayer = L.layerGroup().addTo(map);
let riversLayer = L.layerGroup();

function styleRisk(feature) {
  const nivel = feature.properties.nivel_risco || "medio";
  return {
    fillColor: RISK_COLORS[nivel] || "#888",
    weight: 1.5,
    opacity: 1,
    color: "#fff",
    fillOpacity: 0.65,
  };
}

function onEachRisk(feature, layer) {
  const p = feature.properties;
  const html = `
    <strong>${p.nome || "Zona de risco"}</strong><br/>
    Nível: <b>${(p.nivel_risco || "-").replace("_", " ")}</b><br/>
    Área: ${p.area_ha ? p.area_ha.toFixed(1) + " ha" : "-"}<br/>
    Município: ${p.municipio || "-"}
  `;
  layer.bindPopup(html);
}

async function loadRiskZones(nivel = "") {
  riskLayer.clearLayers();
  let url = `${API_BASE}/api/risco`;
  if (nivel) url += `?nivel=${encodeURIComponent(nivel)}`;

  try {
    const res = await fetch(url);
    const data = await res.json();
    L.geoJSON(data, {
      style: styleRisk,
      onEachFeature: onEachRisk,
    }).addTo(riskLayer);
  } catch (err) {
    console.error("Failed to load risk zones:", err);
  }
}

async function loadRivers() {
  riversLayer.clearLayers();
  try {
    const res = await fetch(`${API_BASE}/api/rios`);
    const data = await res.json();
    L.geoJSON(data, {
      style: { color: "#00a8e8", weight: 2.5, opacity: 0.9 },
      onEachFeature: (f, layer) => {
        layer.bindPopup(`<b>${f.properties.nome || "Rio"}</b><br/>${f.properties.tipo || ""}`);
      },
    }).addTo(riversLayer);
  } catch (err) {
    console.error("Failed to load rivers:", err);
  }
}

async function loadStats() {
  const container = document.getElementById("stats-container");
  try {
    const res = await fetch(`${API_BASE}/api/analysis/stats`);
    const data = await res.json();
    if (!data.stats || data.stats.length === 0) {
      container.innerHTML = "<p>Sem dados ainda.</p>";
      return;
    }
    container.innerHTML = data.stats
      .map(
        (s) => `
      <div class="stat-row">
        <span>${(s.nivel_risco || "").replace("_", " ")}</span>
        <span>${s.quantidade} zonas • ${Number(s.area_total_ha).toFixed(1)} ha</span>
      </div>`
      )
      .join("");
  } catch (err) {
    container.innerHTML = "<p class='loading'>Erro ao carregar estatísticas</p>";
  }
}

// Event listeners
document.getElementById("layer-risco").addEventListener("change", (e) => {
  if (e.target.checked) {
    map.addLayer(riskLayer);
  } else {
    map.removeLayer(riskLayer);
  }
});

document.getElementById("layer-rios").addEventListener("change", (e) => {
  if (e.target.checked) {
    map.addLayer(riversLayer);
    loadRivers();
  } else {
    map.removeLayer(riversLayer);
  }
});

document.getElementById("filtro-nivel").addEventListener("change", (e) => {
  loadRiskZones(e.target.value);
});

// Initial load
loadRiskZones();
loadStats();
