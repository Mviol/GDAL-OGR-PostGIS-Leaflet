"""
GeoRisco API - FastAPI backend
Exposes geospatial data and analysis results for the Leaflet frontend.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from routers import risk, analysis, health

app = FastAPI(
    title="GeoRisco API",
    description="Web GIS backend for urban flood risk analysis. Integrates GDAL/OGR processed data and spatial analysis.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, tags=["Health"])
app.include_router(risk.router, prefix="/api", tags=["Risk Zones"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["Spatial Analysis"])


@app.get("/")
def root():
    return {
        "project": "GeoRisco",
        "message": "Urban Flood Risk GIS API",
        "docs": "/docs",
        "version": "1.0.0",
    }
