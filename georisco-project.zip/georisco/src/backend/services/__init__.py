# Services package – place TerraLib wrappers or complex spatial logic here
