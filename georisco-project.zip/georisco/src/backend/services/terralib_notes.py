"""
TerraLib integration notes (didactic module)

TerraLib is a powerful C++ GIS library developed mainly in Brazil (INPE / partners).
Native Python bindings exist but are not always straightforward to install in
lightweight Docker images.

Recommended approaches for this project:

1. Didactic / teaching path
   - Keep TerraLib as a documented advanced module.
   - Provide a separate service or container that compiles TerraLib + Python bindings.
   - Call it via REST or subprocess from the main FastAPI app.

2. Production path (what we use by default)
   - PostGIS + GDAL/OGR + GeoPandas/Shapely cover 95% of the needed operations
     (buffer, intersection, overlay, area, proximity, raster algebra, etc.).

3. Hybrid
   - Use TerraLib for specific advanced algorithms (e.g. some cellular automata
     or specialized spatial statistics) and PostGIS for everything else.

If you want to experiment with TerraLib:

- Official site: http://www.terralib.org/
- Look for TerraLib 5.x and the Python package (if available for your platform).
- Consider building a dedicated Docker image based on Ubuntu with the full
  TerraLib stack.

This file intentionally contains no runtime dependency on TerraLib so the
project remains easy to run for everyone.
"""
