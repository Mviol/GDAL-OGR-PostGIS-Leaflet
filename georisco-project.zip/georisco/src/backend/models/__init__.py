# Models package (Pydantic / SQLAlchemy can be added here)
