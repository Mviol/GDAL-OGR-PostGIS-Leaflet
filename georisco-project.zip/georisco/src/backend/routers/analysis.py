"""
Spatial analysis endpoints (buffer, intersection summary, area stats).
These call the same logic that can later be replaced by TerraLib modules.
"""

from fastapi import APIRouter, Query
from typing import Optional
import os
import psycopg2
from psycopg2.extras import RealDictCursor

router = APIRouter()


def get_conn():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "db"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        dbname=os.getenv("POSTGRES_DB", "georisco"),
        user=os.getenv("POSTGRES_USER", "geo"),
        password=os.getenv("POSTGRES_PASSWORD", "geo123"),
    )


@router.get("/stats")
def risk_stats():
    """Summary statistics of risk zones by level."""
    try:
        conn = get_conn()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("""
            SELECT nivel_risco,
                   COUNT(*) AS quantidade,
                   COALESCE(SUM(area_ha), 0) AS area_total_ha
            FROM georisco.zonas_risco
            GROUP BY nivel_risco
            ORDER BY 
                CASE nivel_risco
                    WHEN 'muito_alto' THEN 1
                    WHEN 'alto' THEN 2
                    WHEN 'medio' THEN 3
                    WHEN 'baixo' THEN 4
                    ELSE 5
                END
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        if not rows:
            # Demo stats
            return {
                "source": "demo",
                "stats": [
                    {"nivel_risco": "muito_alto", "quantidade": 1, "area_total_ha": 22.1},
                    {"nivel_risco": "alto", "quantidade": 1, "area_total_ha": 45.2},
                    {"nivel_risco": "medio", "quantidade": 1, "area_total_ha": 78.5},
                ],
            }
        return {"source": "database", "stats": [dict(r) for r in rows]}
    except Exception as e:
        return {"source": "error", "detail": str(e), "stats": []}


@router.get("/buffer-rios")
def buffer_rivers(distance: float = Query(200.0, description="Buffer distance in meters")):
    """
    Returns a simple message describing a buffer analysis.
    In a full deployment this would create/return the buffer layer.
    """
    return {
        "operation": "buffer",
        "source": "georisco.rios",
        "distance_meters": distance,
        "note": "In production this endpoint triggers PostGIS ST_Buffer (or TerraLib equivalent) and returns the resulting GeoJSON.",
        "status": "demo",
    }
