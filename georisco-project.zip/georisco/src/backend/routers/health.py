from fastapi import APIRouter
import os
import psycopg2

router = APIRouter()


@router.get("/health")
def health_check():
    db_ok = False
    try:
        conn = psycopg2.connect(
            host=os.getenv("POSTGRES_HOST", "db"),
            port=os.getenv("POSTGRES_PORT", "5432"),
            dbname=os.getenv("POSTGRES_DB", "georisco"),
            user=os.getenv("POSTGRES_USER", "geo"),
            password=os.getenv("POSTGRES_PASSWORD", "geo123"),
            connect_timeout=3,
        )
        conn.close()
        db_ok = True
    except Exception:
        pass

    return {
        "status": "ok" if db_ok else "degraded",
        "database": "connected" if db_ok else "unreachable",
    }
