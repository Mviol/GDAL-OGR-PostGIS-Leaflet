"""
Risk zones endpoints – returns GeoJSON for Leaflet.
"""

from fastapi import APIRouter, Query, HTTPException
from typing import Optional
import os
import json
import psycopg2
from psycopg2.extras import RealDictCursor

router = APIRouter()


def get_conn():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "db"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        dbname=os.getenv("POSTGRES_DB", "georisco"),
        user=os.getenv("POSTGRES_USER", "geo"),
        password=os.getenv("POSTGRES_PASSWORD", "geo123"),
    )


@router.get("/risco")
def get_risk_zones(
    nivel: Optional[str] = Query(None, description="Filter by risk level: baixo, medio, alto, muito_alto"),
    municipio: Optional[str] = Query(None, description="Filter by municipality name"),
):
    """
    Returns flood risk zones as GeoJSON FeatureCollection.
    """
    try:
        conn = get_conn()
        cur = conn.cursor(cursor_factory=RealDictCursor)

        # Check if table has data; if empty, return demo features
        cur.execute("SELECT COUNT(*) AS n FROM georisco.zonas_risco")
        count = cur.fetchone()["n"]

        if count == 0:
            # Demo data centered roughly on a Brazilian city (example: region of Belo Horizonte / generic)
            demo = {
                "type": "FeatureCollection",
                "features": [
                    {
                        "type": "Feature",
                        "properties": {
                            "id": 1,
                            "nome": "Zona Centro - Risco Alto",
                            "nivel_risco": "alto",
                            "area_ha": 45.2,
                            "municipio": "Exemplo",
                        },
                        "geometry": {
                            "type": "Polygon",
                            "coordinates": [[
                                [-43.95, -19.92],
                                [-43.93, -19.92],
                                [-43.93, -19.90],
                                [-43.95, -19.90],
                                [-43.95, -19.92],
                            ]],
                        },
                    },
                    {
                        "type": "Feature",
                        "properties": {
                            "id": 2,
                            "nome": "Zona Norte - Risco Médio",
                            "nivel_risco": "medio",
                            "area_ha": 78.5,
                            "municipio": "Exemplo",
                        },
                        "geometry": {
                            "type": "Polygon",
                            "coordinates": [[
                                [-43.94, -19.89],
                                [-43.91, -19.89],
                                [-43.91, -19.87],
                                [-43.94, -19.87],
                                [-43.94, -19.89],
                            ]],
                        },
                    },
                    {
                        "type": "Feature",
                        "properties": {
                            "id": 3,
                            "nome": "Zona Ribeirinha - Risco Muito Alto",
                            "nivel_risco": "muito_alto",
                            "area_ha": 22.1,
                            "municipio": "Exemplo",
                        },
                        "geometry": {
                            "type": "Polygon",
                            "coordinates": [[
                                [-43.96, -19.93],
                                [-43.94, -19.93],
                                [-43.94, -19.91],
                                [-43.96, -19.91],
                                [-43.96, -19.93],
                            ]],
                        },
                    },
                ],
            }
            cur.close()
            conn.close()
            return demo

        sql = """
            SELECT id, nome, nivel_risco, area_ha, municipio,
                   ST_AsGeoJSON(geom)::json AS geometry
            FROM georisco.zonas_risco
            WHERE 1=1
        """
        params = []
        if nivel:
            sql += " AND nivel_risco = %s"
            params.append(nivel)
        if municipio:
            sql += " AND municipio ILIKE %s"
            params.append(f"%{municipio}%")

        cur.execute(sql, params)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        features = []
        for row in rows:
            geom = row.pop("geometry")
            features.append({
                "type": "Feature",
                "properties": dict(row),
                "geometry": geom,
            })

        return {"type": "FeatureCollection", "features": features}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/rios")
def get_rivers():
    """Returns river network as GeoJSON (or empty collection if no data)."""
    try:
        conn = get_conn()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("""
            SELECT id, nome, tipo, ST_AsGeoJSON(geom)::json AS geometry
            FROM georisco.rios
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        features = [
            {
                "type": "Feature",
                "properties": {"id": r["id"], "nome": r["nome"], "tipo": r["tipo"]},
                "geometry": r["geometry"],
            }
            for r in rows
        ]
        return {"type": "FeatureCollection", "features": features}
    except Exception as e:
        return {"type": "FeatureCollection", "features": []}
