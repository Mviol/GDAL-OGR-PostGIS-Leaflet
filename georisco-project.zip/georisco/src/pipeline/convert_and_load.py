#!/usr/bin/env python3
"""
GeoRisco - Data pipeline using GDAL/OGR
Ingests Shapefile / GeoJSON / GeoTIFF → converts → loads into PostGIS
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from osgeo import gdal, ogr, osr

# Enable GDAL exceptions
gdal.UseExceptions()
ogr.UseExceptions()

DATA_RAW = Path(os.getenv("DATA_RAW", "/data/raw"))
DATA_PROCESSED = Path(os.getenv("DATA_PROCESSED", "/data/processed"))
PG_CONN = os.getenv(
    "PG_CONN",
    "PG:host=db port=5432 dbname=georisco user=geo password=geo123"
)


def ensure_dirs():
    DATA_RAW.mkdir(parents=True, exist_ok=True)
    DATA_PROCESSED.mkdir(parents=True, exist_ok=True)


def convert_shapefile_to_geojson(shp_path: Path, out_path: Path) -> Path:
    """Convert Shapefile to GeoJSON using GDAL/OGR."""
    print(f"[GDAL] Converting {shp_path.name} → GeoJSON...")
    src_ds = ogr.Open(str(shp_path))
    if src_ds is None:
        raise RuntimeError(f"Could not open {shp_path}")

    driver = ogr.GetDriverByName("GeoJSON")
    if out_path.exists():
        driver.DeleteDataSource(str(out_path))

    driver.CopyDataSource(src_ds, str(out_path))
    src_ds = None
    print(f"  → Saved: {out_path}")
    return out_path


def load_to_postgis(
    input_path: Path,
    table_name: str,
    schema: str = "georisco",
    srid: int = 4326,
    overwrite: bool = True,
) -> None:
    """
    Load vector data into PostGIS using ogr2ogr (most robust method).
    """
    full_table = f"{schema}.{table_name}"
    print(f"[GDAL] Loading {input_path.name} → {full_table}...")

    cmd = [
        "ogr2ogr",
        "-f", "PostgreSQL",
        PG_CONN,
        str(input_path),
        "-nln", full_table,
        "-lco", "GEOMETRY_NAME=geom",
        "-lco", "FID=id",
        "-t_srs", f"EPSG:{srid}",
        "-nlt", "PROMOTE_TO_MULTI",
    ]
    if overwrite:
        cmd.append("-overwrite")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("STDERR:", result.stderr)
        raise RuntimeError(f"ogr2ogr failed for {input_path}")
    print(f"  → Table {full_table} loaded successfully.")


def create_buffer_analysis(
    source_table: str = "georisco.rios",
    distance_meters: float = 200.0,
    target_table: str = "georisco.buffer_rios",
) -> None:
    """
    Example spatial analysis: create buffer around rivers.
    This is a pure PostGIS operation (can be extended with TerraLib later).
    """
    import psycopg2

    print(f"[Spatial] Creating {distance_meters}m buffer around {source_table}...")
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "db"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        dbname=os.getenv("POSTGRES_DB", "georisco"),
        user=os.getenv("POSTGRES_USER", "geo"),
        password=os.getenv("POSTGRES_PASSWORD", "geo123"),
    )
    cur = conn.cursor()

    cur.execute(f"""
        DROP TABLE IF EXISTS {target_table};
        CREATE TABLE {target_table} AS
        SELECT
            id,
            nome,
            ST_Transform(
                ST_Buffer(ST_Transform(geom, 3857), {distance_meters}),
                4326
            )::geometry(MultiPolygon, 4326) AS geom
        FROM {source_table};
        CREATE INDEX ON {target_table} USING GIST (geom);
    """)
    conn.commit()
    cur.close()
    conn.close()
    print(f"  → Buffer table {target_table} created.")


def run_pipeline(sample: bool = True):
    """Main entry point of the data pipeline."""
    ensure_dirs()
    print("=" * 60)
    print("GeoRisco – GDAL/OGR Data Pipeline")
    print("=" * 60)

    # In a real scenario you would place real Shapefiles in data/raw/
    # Here we just demonstrate the flow. For demo we expect files already present
    # or we skip if missing.

    shp_files = list(DATA_RAW.glob("*.shp"))
    geojson_files = list(DATA_RAW.glob("*.geojson")) + list(DATA_RAW.glob("*.json"))

    if not shp_files and not geojson_files:
        print("[INFO] No input files found in data/raw/.")
        print("       Place .shp or .geojson files there and re-run.")
        print("       Example: data/raw/zonas_risco.shp")
        return

    for shp in shp_files:
        geojson = DATA_PROCESSED / f"{shp.stem}.geojson"
        convert_shapefile_to_geojson(shp, geojson)
        # Decide table name from filename
        table = shp.stem.lower().replace(" ", "_")
        load_to_postgis(geojson, table)

    for gj in geojson_files:
        table = gj.stem.lower().replace(" ", "_")
        load_to_postgis(gj, table)

    # Example analysis
    try:
        create_buffer_analysis()
    except Exception as e:
        print(f"[WARN] Buffer analysis skipped: {e}")

    print("=" * 60)
    print("Pipeline finished.")
    print("=" * 60)


if __name__ == "__main__":
    run_pipeline()
