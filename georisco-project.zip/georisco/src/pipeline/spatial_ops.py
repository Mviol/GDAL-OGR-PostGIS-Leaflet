#!/usr/bin/env python3
"""
GeoRisco - Spatial analysis helpers
Demonstrates classic GIS operations that can later be replaced/augmented by TerraLib.
"""

import os
from typing import List, Dict, Any

import psycopg2
from psycopg2.extras import RealDictCursor


def get_connection():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "db"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        dbname=os.getenv("POSTGRES_DB", "georisco"),
        user=os.getenv("POSTGRES_USER", "geo"),
        password=os.getenv("POSTGRES_PASSWORD", "geo123"),
    )


def buffer(table: str, distance_m: float, geom_col: str = "geom") -> str:
    """Create a buffer and return the name of the result table."""
    result_table = f"{table}_buffer_{int(distance_m)}m"
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                DROP TABLE IF EXISTS {result_table};
                CREATE TABLE {result_table} AS
                SELECT id,
                       ST_Transform(
                           ST_Buffer(ST_Transform({geom_col}, 3857), %s),
                           4326
                       ) AS geom
                FROM {table};
            """, (distance_m,))
            conn.commit()
    return result_table


def intersection(table_a: str, table_b: str, result_name: str = "intersecao") -> str:
    """Compute geometric intersection between two layers."""
    full_result = f"georisco.{result_name}"
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                DROP TABLE IF EXISTS {full_result};
                CREATE TABLE {full_result} AS
                SELECT
                    a.id AS id_a,
                    b.id AS id_b,
                    ST_Intersection(a.geom, b.geom) AS geom
                FROM {table_a} a
                JOIN {table_b} b ON ST_Intersects(a.geom, b.geom)
                WHERE NOT ST_IsEmpty(ST_Intersection(a.geom, b.geom));
                CREATE INDEX ON {full_result} USING GIST (geom);
            """)
            conn.commit()
    return full_result


def area_ha(table: str, geom_col: str = "geom") -> List[Dict[str, Any]]:
    """Calculate area in hectares for each feature."""
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(f"""
                SELECT id,
                       ST_Area(ST_Transform({geom_col}, 3857)) / 10000.0 AS area_ha
                FROM {table};
            """)
            return [dict(row) for row in cur.fetchall()]


def proximity(table_a: str, table_b: str, max_distance_m: float = 500) -> List[Dict]:
    """Find features of A that are within max_distance of any feature of B."""
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(f"""
                SELECT DISTINCT a.id AS id_a,
                       MIN(ST_Distance(
                           ST_Transform(a.geom, 3857),
                           ST_Transform(b.geom, 3857)
                       )) AS dist_m
                FROM {table_a} a
                CROSS JOIN {table_b} b
                WHERE ST_DWithin(
                    ST_Transform(a.geom, 3857),
                    ST_Transform(b.geom, 3857),
                    %s
                )
                GROUP BY a.id
                ORDER BY dist_m;
            """, (max_distance_m,))
            return [dict(row) for row in cur.fetchall()]


if __name__ == "__main__":
    print("Spatial ops module – import and use the functions.")
    print("Available: buffer, intersection, area_ha, proximity")
