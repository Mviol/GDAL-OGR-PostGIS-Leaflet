-- GeoRisco - Initial PostGIS schema
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

-- Schema for flood risk analysis
CREATE SCHEMA IF NOT EXISTS georisco;

-- Rivers / drainage network
CREATE TABLE IF NOT EXISTS georisco.rios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150),
    tipo VARCHAR(50),
    geom GEOMETRY(MultiLineString, 4326)
);

-- Flood risk zones (polygons)
CREATE TABLE IF NOT EXISTS georisco.zonas_risco (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150),
    nivel_risco VARCHAR(20) CHECK (nivel_risco IN ('baixo', 'medio', 'alto', 'muito_alto')),
    area_ha NUMERIC(12,2),
    municipio VARCHAR(100),
    geom GEOMETRY(MultiPolygon, 4326)
);

-- Urban occupation / buildings (simplified)
CREATE TABLE IF NOT EXISTS georisco.ocupacao (
    id SERIAL PRIMARY KEY,
    tipo VARCHAR(50),
    populacao_estimada INTEGER,
    geom GEOMETRY(MultiPolygon, 4326)
);

-- Spatial indexes
CREATE INDEX IF NOT EXISTS idx_rios_geom ON georisco.rios USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_zonas_geom ON georisco.zonas_risco USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_ocupacao_geom ON georisco.ocupacao USING GIST (geom);

-- Sample view for quick API consumption
CREATE OR REPLACE VIEW georisco.v_risco_resumo AS
SELECT
    z.id,
    z.nome,
    z.nivel_risco,
    z.area_ha,
    z.municipio,
    ST_AsGeoJSON(z.geom)::json AS geometry
FROM georisco.zonas_risco z;

COMMENT ON TABLE georisco.zonas_risco IS 'Zonas de risco de inundação / Flood risk zones';
COMMENT ON TABLE georisco.rios IS 'Rede de drenagem / Drainage network';
