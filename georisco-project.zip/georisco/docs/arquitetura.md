# Arquitetura do GeoRisco

## Visão geral

```
[Arquivos brutos] → GDAL/OGR (pipeline) → PostGIS
                                          ↓
                                    FastAPI (API)
                                          ↓
                                    Leaflet (mapa)
```

## Componentes

1. **Pipeline (src/pipeline)**  
   - `convert_and_load.py`: conversão Shapefile/GeoJSON → PostGIS via ogr2ogr  
   - `spatial_ops.py`: buffer, interseção, área, proximidade

2. **Banco**  
   - PostgreSQL 16 + PostGIS 3.4  
   - Schema `georisco` com tabelas de rios, zonas de risco e ocupação

3. **API (src/backend)**  
   - FastAPI  
   - Endpoints: `/api/risco`, `/api/rios`, `/api/analysis/stats`

4. **Frontend (src/frontend)**  
   - HTML + CSS + Leaflet puro  
   - Camadas, filtros, legenda e estatísticas

5. **TerraLib**  
   - Mantida como módulo didático (`services/terralib_notes.py`)  
   - Em produção usamos PostGIS + GDAL por praticidade

## Níveis de complexidade

- **Iniciante**: rodar o docker-compose e explorar o mapa  
- **Intermediário**: adicionar novos Shapefiles e criar análises  
- **Avançado**: integrar TerraLib nativamente ou estender a API
