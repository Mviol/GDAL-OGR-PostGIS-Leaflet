# Integração com TerraLib

A TerraLib é uma biblioteca C++ de geoprocessamento desenvolvida no Brasil.

## Por que não é a base de produção deste projeto?

- Compilação e bindings Python podem ser complexos em ambientes leves
- PostGIS + GDAL cobrem a maioria dos casos de uso de forma mais simples

## Como usar TerraLib de forma didática

1. Crie um container separado com Ubuntu + TerraLib compilada
2. Exponha as análises via uma API interna
3. Chame essa API a partir do FastAPI principal

Consulte `src/backend/services/terralib_notes.py` para mais detalhes.
