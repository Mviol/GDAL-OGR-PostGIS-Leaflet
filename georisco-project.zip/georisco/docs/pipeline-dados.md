# Pipeline de Dados

## Fluxo

1. Coloque arquivos em `data/raw/` (Shapefile, GeoJSON, etc.)
2. Execute o pipeline:
   ```bash
   docker compose exec api python /data/../src/pipeline/convert_and_load.py
   ```
   (ou monte o volume corretamente e rode localmente)

3. Os dados são convertidos e carregados no schema `georisco`

## Operações espaciais disponíveis

- Buffer
- Interseção
- Cálculo de área (ha)
- Proximidade (ST_DWithin)

Todas implementadas em `src/pipeline/spatial_ops.py` e também via SQL no PostGIS.
