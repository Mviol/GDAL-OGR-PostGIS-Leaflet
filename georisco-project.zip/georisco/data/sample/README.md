# Sample data

Place small example GeoJSON or Shapefile files here for demos.

The API already returns demo risk zones when the database tables are empty, so the map works out of the box.
