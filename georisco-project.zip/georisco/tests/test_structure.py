"""Basic structural tests for GeoRisco."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_docker_compose_exists():
    assert (ROOT / "docker-compose.yml").exists()


def test_backend_main_exists():
    assert (ROOT / "src" / "backend" / "main.py").exists()


def test_frontend_index_exists():
    assert (ROOT / "src" / "frontend" / "index.html").exists()


def test_pipeline_exists():
    assert (ROOT / "src" / "pipeline" / "convert_and_load.py").exists()
