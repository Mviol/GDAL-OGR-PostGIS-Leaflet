# GeoRisco 🌊🗺️

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![PostGIS](https://img.shields.io/badge/PostGIS-3.4-blue.svg)](https://postgis.net)
[![Leaflet](https://img.shields.io/badge/Leaflet-1.9-green.svg)](https://leafletjs.com)

**Complete web Geographic Information System (GIS)** focused on **urban flood risk analysis**.

It integrates in a didactic and functional way:

- **GDAL/OGR** → ingestion, conversion and processing of geospatial data  
- **TerraLib** → didactic module for advanced spatial analysis  
- **Leaflet** → interactive visualization in the browser  
- **PostGIS** → production spatial database  

---

## Quick start

```bash
git clone https://github.com/your-username/georisco.git
cd georisco
cp .env.example .env
docker compose up --build
```

- Map: http://localhost:8080  
- API + Swagger: http://localhost:8000/docs  

The map already works with demo data even without loading external files.

---

## Features

- Data pipeline with GDAL/OGR (Shapefile → GeoJSON → PostGIS)
- REST API (FastAPI) that returns GeoJSON
- Leaflet map with layers, filters, popups, legend and live statistics
- Spatial analyses: buffer, intersection, area, proximity
- Full Docker Compose stack

---

## Repository structure

```text
georisco/
├── docker-compose.yml
├── src/
│   ├── pipeline/          # GDAL/OGR scripts
│   ├── backend/           # FastAPI
│   └── frontend/          # Leaflet
├── data/
├── docs/
├── scripts/
└── notebooks/
```

---

## Skill levels

| Level        | What to do                                      |
|--------------|-------------------------------------------------|
| Beginner     | `docker compose up` and explore the map         |
| Intermediate | Add Shapefiles and run the pipeline             |
| Advanced     | Extend analyses or integrate TerraLib natively  |

---

## Documentation

- [Architecture](docs/arquitetura.md)
- [Data pipeline](docs/pipeline-dados.md)
- [TerraLib integration](docs/terra-lib-integracao.md)

---

## License

MIT © 2026 GeoRisco Contributors
