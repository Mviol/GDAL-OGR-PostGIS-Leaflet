# GeoRisco 🌊🗺️

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![PostGIS](https://img.shields.io/badge/PostGIS-3.4-blue.svg)](https://postgis.net)
[![Leaflet](https://img.shields.io/badge/Leaflet-1.9-green.svg)](https://leafletjs.com)

**Sistema Informativo Geografico (SIG) web completo** incentrato sull’**analisi del rischio di alluvioni urbane**.

Integra in modo didattico e funzionale:

- **GDAL/OGR** → ingestione, conversione e elaborazione di dati geospaziali  
- **TerraLib** → modulo didattico di analisi spaziale avanzata  
- **Leaflet** → visualizzazione interattiva nel browser  
- **PostGIS** → database spaziale di produzione  

---

## Avvio rapido

```bash
git clone https://github.com/tuo-utente/georisco.git
cd georisco
cp .env.example .env
docker compose up --build
```

- Mappa: http://localhost:8080  
- API + Swagger: http://localhost:8000/docs  

La mappa funziona già con dati dimostrativi anche senza caricare file esterni.

---

## Funzionalità

- Pipeline di dati con GDAL/OGR (Shapefile → GeoJSON → PostGIS)
- API REST (FastAPI) che restituisce GeoJSON
- Mappa Leaflet con layer, filtri, popup, legenda e statistiche
- Analisi spaziali: buffer, intersezione, area, prossimità
- Docker Compose completo

---

## Struttura del repository

```text
georisco/
├── docker-compose.yml
├── src/
│   ├── pipeline/          # Script GDAL/OGR
│   ├── backend/           # FastAPI
│   └── frontend/          # Leaflet
├── data/
├── docs/
├── scripts/
└── notebooks/
```

---

## Livelli di utilizzo

| Livello       | Cosa fare                                         |
|---------------|---------------------------------------------------|
| Principiante  | `docker compose up` ed esplorare la mappa         |
| Intermedio    | Aggiungere Shapefile ed eseguire la pipeline      |
| Avanzato      | Estendere le analisi o integrare TerraLib nativo  |

---

## Documentazione

- [Architettura](docs/arquitetura.md)
- [Pipeline dei dati](docs/pipeline-dados.md)
- [Integrazione TerraLib](docs/terra-lib-integracao.md)

---

## Licenza

MIT © 2026 GeoRisco Contributors
