# GeoRisco 🌊🗺️

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![PostGIS](https://img.shields.io/badge/PostGIS-3.4-blue.svg)](https://postgis.net)
[![Leaflet](https://img.shields.io/badge/Leaflet-1.9-green.svg)](https://leafletjs.com)

**Sistema de Información Geográfica (SIG) web completo** centrado en el **análisis de riesgo de inundaciones urbanas**.

Integra de forma didáctica y funcional:

- **GDAL/OGR** → ingestión, conversión y procesamiento de datos geoespaciales  
- **TerraLib** → módulo didáctico de análisis espacial avanzado  
- **Leaflet** → visualización interactiva en el navegador  
- **PostGIS** → base de datos espacial de producción  

---

## Inicio rápido

```bash
git clone https://github.com/tu-usuario/georisco.git
cd georisco
cp .env.example .env
docker compose up --build
```

- Mapa: http://localhost:8080  
- API + Swagger: http://localhost:8000/docs  

El mapa ya funciona con datos de demostración aunque no se carguen archivos externos.

---

## Funcionalidades

- Pipeline de datos con GDAL/OGR (Shapefile → GeoJSON → PostGIS)
- API REST (FastAPI) que devuelve GeoJSON
- Mapa Leaflet con capas, filtros, popups, leyenda y estadísticas
- Análisis espaciales: buffer, intersección, área, proximidad
- Docker Compose completo

---

## Estructura del repositorio

```text
georisco/
├── docker-compose.yml
├── src/
│   ├── pipeline/          # Scripts GDAL/OGR
│   ├── backend/           # FastAPI
│   └── frontend/          # Leaflet
├── data/
├── docs/
├── scripts/
└── notebooks/
```

---

## Niveles de uso

| Nivel         | Qué hacer                                        |
|---------------|--------------------------------------------------|
| Principiante  | `docker compose up` y explorar el mapa           |
| Intermedio    | Añadir Shapefiles y ejecutar el pipeline         |
| Avanzado      | Extender análisis o integrar TerraLib nativamente|

---

## Documentación

- [Arquitectura](docs/arquitetura.md)
- [Pipeline de datos](docs/pipeline-dados.md)
- [Integración TerraLib](docs/terra-lib-integracao.md)

---

## Licencia

MIT © 2026 GeoRisco Contributors
